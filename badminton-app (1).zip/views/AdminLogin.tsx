
import React, { useState } from 'react';
import { Card, Button, Input } from '../components/ui';
import { ShieldCheck, Lock } from 'lucide-react';

interface AdminLoginProps {
  onSuccess: () => void;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ onSuccess }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Simple mock password for demo purposes
    if (password === 'admin123') {
      onSuccess();
    } else {
      setError('Invalid admin credentials. Please try again.');
    }
  };

  return (
    <div className="max-w-md mx-auto py-12">
      <Card className="p-8">
        <div className="flex flex-col items-center mb-8">
          <div className="bg-indigo-100 p-4 rounded-full mb-4">
            <Lock className="w-8 h-8 text-indigo-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800">Admin Login</h2>
          <p className="text-slate-500 text-center mt-2">Access backend management for events and participants.</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <Input 
            label="Admin Password" 
            type="password" 
            placeholder="Enter password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          {error && <p className="text-rose-500 text-sm font-medium">{error}</p>}
          <Button type="submit" className="w-full py-3 text-base">
            <ShieldCheck className="w-5 h-5" />
            Authenticate
          </Button>
          <p className="text-xs text-slate-400 text-center">Tip: In this demo, use password "admin123"</p>
        </form>
      </Card>
    </div>
  );
};

export default AdminLogin;


import { BadmintonEvent } from '../types';

const STORAGE_KEY = 'smashdash_events';

export const storage = {
  getEvents: (): BadmintonEvent[] => {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  },
  
  saveEvents: (events: BadmintonEvent[]) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(events));
  },

  addEvent: (event: BadmintonEvent) => {
    const events = storage.getEvents();
    events.push(event);
    storage.saveEvents(events);
  },

  updateEvent: (updatedEvent: BadmintonEvent) => {
    const events = storage.getEvents();
    const index = events.findIndex(e => e.id === updatedEvent.id);
    if (index !== -1) {
      events[index] = updatedEvent;
      storage.saveEvents(events);
    }
  },

  deleteEvent: (id: string) => {
    const events = storage.getEvents();
    const filtered = events.filter(e => e.id !== id);
    storage.saveEvents(filtered);
  }
};

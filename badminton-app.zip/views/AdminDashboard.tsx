
import React, { useState, useEffect } from 'react';
import { BadmintonEvent } from '../types';
import { storage } from '../services/storage';
import { Card, Button, Input } from '../components/ui';
import { Plus, Edit2, Trash2, Save, Settings2, Users, Hourglass, Timer, Clock } from 'lucide-react';

interface AdminDashboardProps {
  events: BadmintonEvent[];
  onUpdate: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ events, onUpdate }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<BadmintonEvent>>({});
  
  // Local states for split inputs
  const [startTime, setStartTime] = useState('18:00');
  const [endTime, setEndTime] = useState('20:00');
  const [deadlineDate, setDeadlineDate] = useState('');
  const [deadlineTime, setDeadlineTime] = useState('12:00');

  useEffect(() => {
    if (editingId) {
      const event = events.find(e => e.id === editingId);
      if (event) {
        const [start, end] = event.time.split(' - ');
        setStartTime(start || '18:00');
        setEndTime(end || '20:00');
        
        const d = new Date(event.deadline);
        if (!isNaN(d.getTime())) {
          setDeadlineDate(d.toISOString().split('T')[0]);
          setDeadlineTime(d.toTimeString().slice(0, 5));
        }
      }
    } else if (isAdding) {
      setStartTime('18:00');
      setEndTime('20:00');
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      setDeadlineDate(tomorrow.toISOString().split('T')[0]);
      setDeadlineTime('12:00');
    }
  }, [editingId, isAdding, events]);

  const isValidDate = (dateStr: any) => {
    if (!dateStr) return false;
    const d = new Date(dateStr);
    return d instanceof Date && !isNaN(d.getTime());
  };

  const formatDeadlineFull = (isoString: string) => {
    const d = new Date(isoString);
    if (isNaN(d.getTime())) return 'N/A';
    return d.toLocaleString(undefined, { 
      weekday: 'short',
      year: 'numeric', 
      month: 'long', 
      day: 'numeric', 
      hour: '2-digit', 
      minute: '2-digit', 
      hourCycle: 'h23',
      hour12: false 
    });
  };

  const handleCreate = () => {
    const combinedDeadline = new Date(`${deadlineDate}T${deadlineTime}`).toISOString();
    const newEvent: BadmintonEvent = {
      id: Math.random().toString(36).substr(2, 9),
      title: formData.title || 'New Session',
      venue: formData.venue || '',
      date: formData.date || new Date().toISOString().split('T')[0],
      time: `${startTime} - ${endTime}`,
      maxSlots: formData.maxSlots || 8,
      deadline: combinedDeadline,
      participants: [],
      waitingList: []
    };
    storage.addEvent(newEvent);
    onUpdate();
    setIsAdding(false);
    resetForm();
  };

  const handleUpdate = () => {
    if (!editingId) return;
    const existing = events.find(e => e.id === editingId);
    if (!existing) return;

    const combinedDeadline = new Date(`${deadlineDate}T${deadlineTime}`).toISOString();
    const updated: BadmintonEvent = {
      ...existing,
      ...formData as BadmintonEvent,
      time: `${startTime} - ${endTime}`,
      deadline: combinedDeadline,
    };
    storage.updateEvent(updated);
    onUpdate();
    setEditingId(null);
    resetForm();
  };

  const resetForm = () => {
    setFormData({});
    setStartTime('18:00');
    setEndTime('20:00');
    setDeadlineDate('');
    setDeadlineTime('12:00');
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this event? This cannot be undone.')) {
      storage.deleteEvent(id);
      onUpdate();
    }
  };

  const startEdit = (event: BadmintonEvent) => {
    setEditingId(event.id);
    setFormData(event);
  };

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Admin Dashboard</h1>
          <p className="text-slate-500">Manage your club's sessions and waiting lists.</p>
        </div>
        <Button onClick={() => setIsAdding(true)}>
          <Plus className="w-5 h-5" />
          Create Event
        </Button>
      </header>

      {(isAdding || editingId) && (
        <Card className="p-6 border-2 border-indigo-100 bg-indigo-50/20">
          <div className="flex items-center gap-2 mb-6">
            <Settings2 className="w-5 h-5 text-indigo-600" />
            <h2 className="text-xl font-bold">{isAdding ? 'Create New Session' : 'Edit Session'}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input 
              label="Session Title" 
              value={formData.title || ''} 
              onChange={e => setFormData({...formData, title: e.target.value})} 
            />
            <Input 
              label="Venue" 
              value={formData.venue || ''} 
              onChange={e => setFormData({...formData, venue: e.target.value})} 
            />
            <Input 
              label="Session Date" 
              type="date"
              value={formData.date || ''} 
              onChange={e => setFormData({...formData, date: e.target.value})} 
            />
            
            <div className="space-y-1">
              <label className="block text-sm font-medium text-slate-700">Session Duration </label>
              <div className="flex items-center gap-2">
                <input 
                  type="time" 
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  value={startTime}
                  onChange={e => setStartTime(e.target.value)}
                />
                <span className="text-slate-400">to</span>
                <input 
                  type="time" 
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  value={endTime}
                  onChange={e => setEndTime(e.target.value)}
                />
              </div>
            </div>

            <Input 
              label="Max Slots" 
              type="number"
              value={formData.maxSlots || ''} 
              onChange={e => setFormData({...formData, maxSlots: parseInt(e.target.value) || 0})} 
            />

            <div className="space-y-1">
              <label className="block text-sm font-medium text-slate-700">Sign-up Deadline</label>
              <div className="flex items-center gap-2">
                <input 
                  type="date" 
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  value={deadlineDate}
                  onChange={e => setDeadlineDate(e.target.value)}
                />
                <input 
                  type="time" 
                  className="w-32 px-3 py-2 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  value={deadlineTime}
                  onChange={e => setDeadlineTime(e.target.value)}
                />
              </div>
            </div>
          </div>
          <div className="flex gap-3 mt-8">
            <Button onClick={isAdding ? handleCreate : handleUpdate}>
              <Save className="w-5 h-5" />
              {isAdding ? 'Create Session' : 'Save Changes'}
            </Button>
            <Button variant="ghost" onClick={() => { setIsAdding(false); setEditingId(null); resetForm(); }}>
              Cancel
            </Button>
          </div>
        </Card>
      )}

      <div className="grid gap-4">
        {events.map(event => (
          <Card key={event.id} className="p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 group">
            <div className="space-y-3 flex-1">
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-1">{event.title}</h3>
                <span className="font-semibold text-indigo-600 flex items-center gap-1.5">
                  <Clock className="w-4 h-4" />
                  {new Date(event.date).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })} @ {event.time}
                </span>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 gap-x-6 text-sm">
                <div className="flex flex-col gap-1 p-3 bg-indigo-50/50 rounded-xl border border-indigo-100">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1">
                    <Timer className="w-3 h-3" />
                    Sign-up Deadline
                  </span>
                  <span className="font-medium text-slate-700 leading-tight">
                    {formatDeadlineFull(event.deadline)}
                  </span>
                </div>
                
                <div className="flex flex-col gap-1 p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    Roster Status
                  </span>
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-slate-700">
                      {event.participants.length} / {event.maxSlots} joined
                    </span>
                    {event.waitingList.length > 0 && (
                      <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded flex items-center gap-1 uppercase tracking-tighter">
                        <Hourglass className="w-2.5 h-2.5" />
                        {event.waitingList.length} Waiting
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex md:flex-col gap-2 shrink-0 w-full md:w-auto">
              <Button variant="secondary" className="flex-1 md:w-full" onClick={() => startEdit(event)}>
                <Edit2 className="w-4 h-4" />
                Edit
              </Button>
              <Button variant="danger" className="flex-1 md:w-full" onClick={() => handleDelete(event.id)}>
                <Trash2 className="w-4 h-4" />
                Delete
              </Button>
            </div>
          </Card>
        ))}
        {events.length === 0 && !isAdding && (
          <div className="py-20 text-center border-2 border-dashed border-slate-200 rounded-xl">
            <p className="text-slate-400">No events found. Create your first session above.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;

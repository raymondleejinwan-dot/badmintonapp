
import React, { useState, useEffect, useRef } from 'react';
import { BadmintonEvent } from '../types';
import { Card, Button } from '../components/ui';
import { Calendar, MapPin, Clock, Users, ChevronRight, X, AlertCircle, Timer, Hourglass, Share2, Check, Star, Trophy } from 'lucide-react';

interface MemberViewProps {
  events: BadmintonEvent[];
  onJoin: (eventId: string, name: string, forceWaiting?: boolean) => void;
  onLeave: (eventId: string, participantId: string) => void;
  highlightSessionId?: string;
}

const MemberView: React.FC<MemberViewProps> = ({ events, onJoin, onLeave, highlightSessionId }) => {
  const [joiningEventId, setJoiningEventId] = useState<string | null>(null);
  const [userName, setUserName] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const sessionRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});

  useEffect(() => {
    if (highlightSessionId && sessionRefs.current[highlightSessionId]) {
      sessionRefs.current[highlightSessionId]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [highlightSessionId]);

  const handleShare = (eventId: string) => {
    const url = `${window.location.origin}${window.location.pathname}#/session/${eventId}`;
    navigator.clipboard.writeText(url);
    setCopiedId(eventId);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const formatDateSafely = (dateStr: string, options?: Intl.DateTimeFormatOptions) => {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return 'Invalid Date';
    return d.toLocaleString(undefined, { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric', 
      hour: '2-digit', 
      minute: '2-digit', 
      hourCycle: 'h23',
      hour12: false, 
      ...options 
    });
  };

  const formatTimeSafely = (dateStr: string) => {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return '--:--';
    return d.toLocaleTimeString(undefined, { 
      hour: '2-digit', 
      minute: '2-digit', 
      hourCycle: 'h23',
      hour12: false 
    });
  };

  const isDeadlinePassed = (deadline: string) => {
    const d = new Date(deadline);
    if (isNaN(d.getTime())) return false;
    return new Date() > d;
  };

  const handleJoinClick = (eventId: string) => {
    setJoiningEventId(eventId);
  };

  const submitJoin = (eventId: string, forceWaiting: boolean = false) => {
    if (userName.trim()) {
      onJoin(eventId, userName.trim(), forceWaiting);
      setUserName('');
      setJoiningEventId(null);
    }
  };

  return (
    <div className="space-y-12">
      {/* Hero Header Integrated from HomeView */}
      <section className="relative py-12 md:py-16 px-8 md:px-12 overflow-hidden rounded-[2.5rem] bg-indigo-950 text-white shadow-2xl shadow-indigo-900/40">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-indigo-300 via-indigo-600 to-transparent scale-150 animate-pulse"></div>
        <div className="relative max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/30 border border-indigo-400/30 text-indigo-200 text-[10px] font-black uppercase tracking-widest mb-6">
            <Star className="w-3 h-3 fill-current" />
            Join the Premier Club
          </div>
          <h1 className="text-5xl md:text-6xl font-black tracking-tight mb-6 leading-tight">
            Elevate Your <br />
            <span className="text-indigo-400">Badminton</span> Game
          </h1>
          <p className="text-lg text-indigo-100/80 mb-8 max-w-xl leading-relaxed font-medium">
            Professional session management, real-time rosters, and a community built for performance and fun. Scroll down to see our active court sessions.
          </p>
          <div className="flex flex-wrap gap-8 items-center pt-4 border-t border-white/10">
            <div className="flex flex-col">
              <span className="text-3xl font-black text-white">30+</span>
              <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">Players</span>
            </div>
            <div className="flex flex-col">
              <span className="text-3xl font-black text-white">{events.length}</span>
              <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">Active Runs</span>
            </div>
            <div className="flex flex-col">
              <span className="text-3xl font-black text-white">4</span>
              <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">Venues</span>
            </div>
          </div>
        </div>
        <div className="absolute -right-20 -bottom-20 opacity-10 hidden lg:block">
           <Trophy className="w-96 h-96 text-white rotate-12" />
        </div>
      </section>

      {/* Sessions Content */}
      <div className="space-y-8 pt-4">
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-2">
            <h2 className="text-4xl font-black text-slate-900 tracking-tight">Active Sessions</h2>
            <p className="text-slate-500 font-medium">Book your spot for upcoming club matches and meet the team.</p>
          </div>
          <div className="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-widest bg-slate-200 px-4 py-2 rounded-full border border-slate-300">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            {events.length} Live Sessions
          </div>
        </header>

        {events.length === 0 ? (
          <Card className="p-16 text-center border-dashed border-2 border-slate-200 bg-transparent shadow-none">
            <div className="bg-white w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-slate-200">
              <Calendar className="text-indigo-400 w-10 h-10" />
            </div>
            <h3 className="text-xl font-bold text-slate-800">No sessions scheduled</h3>
            <p className="text-slate-500 max-w-xs mx-auto">Our admins are currently organizing the next slate of matches. Check back shortly!</p>
          </Card>
        ) : (
          <div className="grid gap-8">
            {events.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()).map(event => {
              const deadlinePassed = isDeadlinePassed(event.deadline);
              const slotsLeft = event.maxSlots - event.participants.length;
              const isFull = slotsLeft <= 0;
              const isHighlighted = highlightSessionId === event.id;

              return (
                <div 
                  key={event.id} 
                  ref={el => { sessionRefs.current[event.id] = el; }}
                  className={`transition-all duration-700 ${isHighlighted ? 'ring-4 ring-indigo-500 ring-offset-8 rounded-3xl scale-[1.02]' : ''}`}
                >
                  <Card className="hover:shadow-2xl hover:shadow-indigo-500/10 transition-all border-none shadow-xl shadow-slate-200/60">
                    <div className="p-8">
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                        <div className="space-y-4 flex-1">
                          <div className="flex flex-wrap items-center gap-3">
                            <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border ${deadlinePassed ? 'bg-rose-50 text-rose-600 border-rose-200' : isFull ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}`}>
                              {deadlinePassed ? 'Registration Closed' : isFull ? 'Waiting List Only' : 'Open Registration'}
                            </span>
                            <button 
                              onClick={() => handleShare(event.id)}
                              className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-slate-50 border border-slate-200 text-[10px] font-bold text-slate-500 hover:text-indigo-600 hover:border-indigo-200 transition-all uppercase tracking-widest"
                            >
                              {copiedId === event.id ? <Check className="w-3 h-3 text-emerald-500" /> : <Share2 className="w-3 h-3" />}
                              {copiedId === event.id ? 'Copied' : 'Share'}
                            </button>
                          </div>
                          
                          <h3 className="text-3xl font-black text-slate-900 leading-none">{event.title}</h3>
                          
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-slate-600">
                            <div className="flex items-center gap-3">
                              <div className="p-2 bg-indigo-50 rounded-lg"><Calendar className="w-4 h-4 text-indigo-600" /></div>
                              <span className="text-sm font-bold">{new Date(event.date).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</span>
                            </div>
                            <div className="flex items-center gap-3">
                              <div className="p-2 bg-indigo-50 rounded-lg"><Clock className="w-4 h-4 text-indigo-600" /></div>
                              <span className="text-sm font-bold">{event.time}</span>
                            </div>
                            <div className="flex items-center gap-3">
                              <div className="p-2 bg-indigo-50 rounded-lg"><MapPin className="w-4 h-4 text-indigo-600" /></div>
                              <span className="text-sm font-bold">{event.venue}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-4 py-3 border-t border-slate-50 mt-2">
                            <div className="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-tighter bg-slate-50 px-3 py-1 rounded-lg border border-slate-100">
                              <Timer className="w-4 h-4 text-indigo-400" />
                              Deadline: <span className="text-slate-900">{formatDateSafely(event.deadline)}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col items-center gap-4 bg-slate-50 p-6 rounded-3xl min-w-[180px] border border-slate-200/60 shadow-inner">
                          <div className="text-center">
                            <span className="block text-4xl font-black text-indigo-700 leading-none mb-1">{event.participants.length}</span>
                            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Players</span>
                          </div>
                          <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden shadow-inner">
                            <div 
                              className={`h-full transition-all duration-1000 ${isFull ? 'bg-amber-500' : 'bg-indigo-600'}`}
                              style={{ width: `${Math.min(100, (event.participants.length / event.maxSlots) * 100)}%` }}
                            ></div>
                          </div>
                          <span className="text-[10px] text-slate-600 font-black uppercase tracking-tighter">
                            {isFull ? `${event.waitingList.length} Waiting` : `${slotsLeft} Slots Left`}
                          </span>
                        </div>
                      </div>

                      <div className="mt-8 border-t border-slate-100 pt-8">
                        <div className="flex flex-col md:flex-row justify-between gap-12">
                          <div className="flex-1 space-y-8">
                            {/* Participants Section */}
                            <div>
                              <h4 className="text-xs font-black text-slate-400 mb-4 flex items-center gap-2 uppercase tracking-widest">
                                <Users className="w-4 h-4 text-indigo-500" />
                                Confirmed Roster ({event.participants.length}/{event.maxSlots})
                              </h4>
                              {event.participants.length === 0 ? (
                                <p className="text-sm text-slate-400 font-medium italic bg-slate-50 p-4 rounded-xl border border-dashed border-slate-200">No players registered for this session yet.</p>
                              ) : (
                                <div className="flex flex-wrap gap-3">
                                  {event.participants.map((p, idx) => (
                                    <div key={p.id} className="group relative flex items-center gap-3 bg-white border border-slate-200 px-4 py-2.5 rounded-xl text-sm font-bold shadow-sm hover:border-indigo-500 hover:shadow-md transition-all">
                                      <span className="flex items-center justify-center w-6 h-6 bg-indigo-100 text-indigo-700 rounded-lg text-[10px]">{idx + 1}</span>
                                      <span className="text-slate-800">{p.name}</span>
                                      {!deadlinePassed && (
                                        <button 
                                          onClick={() => onLeave(event.id, p.id)}
                                          className="ml-2 p-1 text-slate-300 hover:text-rose-600 transition-colors"
                                          title="Leave"
                                        >
                                          <X className="w-4 h-4" />
                                        </button>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>

                            {/* Waiting List Section */}
                            {event.waitingList.length > 0 && (
                              <div className="bg-amber-50/50 p-6 rounded-3xl border border-amber-200/50">
                                <h4 className="text-xs font-black text-amber-800 mb-4 flex items-center gap-2 uppercase tracking-widest">
                                  <Hourglass className="w-4 h-4 text-amber-600" />
                                  Waiting List ({event.waitingList.length})
                                </h4>
                                <div className="flex flex-wrap gap-3">
                                  {event.waitingList.map((p, idx) => (
                                    <div key={p.id} className="group relative flex items-center gap-3 bg-white border border-amber-200 px-4 py-2.5 rounded-xl text-sm font-bold shadow-sm hover:border-amber-600 transition-all">
                                      <span className="flex items-center justify-center w-6 h-6 bg-amber-50 text-amber-700 rounded-lg text-[10px]">W{idx + 1}</span>
                                      <span className="text-slate-800">{p.name}</span>
                                      {!deadlinePassed && (
                                        <button 
                                          onClick={() => onLeave(event.id, p.id)}
                                          className="ml-2 p-1 text-slate-300 hover:text-rose-600 transition-colors"
                                          title="Remove"
                                        >
                                          <X className="w-4 h-4" />
                                        </button>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>

                          <div className="md:w-80 shrink-0 space-y-4">
                            {joiningEventId === event.id ? (
                              <div className="p-6 bg-indigo-950 rounded-3xl space-y-6 shadow-2xl animate-in zoom-in duration-300 border border-white/10">
                                <div className="space-y-2">
                                  <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest ml-1">
                                    Your Information
                                  </p>
                                  <input 
                                    className="w-full px-4 py-4 bg-white/5 border border-white/20 rounded-2xl text-white placeholder-indigo-400/50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all font-bold"
                                    placeholder="Full Name" 
                                    value={userName} 
                                    onChange={(e) => setUserName(e.target.value)}
                                    autoFocus
                                  />
                                </div>
                                
                                <div className="grid gap-4">
                                  {!isFull && (
                                    <Button 
                                      className="w-full h-14 rounded-2xl bg-indigo-500 text-white hover:bg-indigo-400 font-black text-base border-none shadow-xl shadow-indigo-900/50" 
                                      onClick={() => submitJoin(event.id, false)}
                                    >
                                      Join Active Roster
                                    </Button>
                                  )}
                                  
                                  <Button 
                                    variant="ghost"
                                    className="w-full h-14 rounded-2xl border-2 border-indigo-700/50 text-indigo-200 hover:bg-indigo-900 hover:text-white font-bold" 
                                    onClick={() => submitJoin(event.id, true)}
                                  >
                                    {isFull ? 'Join Waiting List' : 'Waitlist (Unsure)'}
                                  </Button>
                                  
                                  <button 
                                    className="w-full text-indigo-500 text-xs font-black uppercase py-2 hover:text-white transition-colors tracking-widest" 
                                    onClick={() => setJoiningEventId(null)}
                                  >
                                    Cancel Registration
                                  </button>
                                </div>
                              </div>
                            ) : (
                              <Button 
                                className={`w-full py-7 rounded-2xl text-xl font-black shadow-xl shadow-indigo-500/20 ${isFull && !deadlinePassed ? 'bg-amber-600 hover:bg-amber-700 shadow-amber-500/20' : ''}`} 
                                disabled={deadlinePassed}
                                onClick={() => handleJoinClick(event.id)}
                              >
                                {deadlinePassed ? 'Session Closed' : isFull ? 'Join Waiting List' : 'Book My Spot'}
                                {!deadlinePassed && <ChevronRight className="w-6 h-6 ml-2" />}
                              </Button>
                            )}
                            {deadlinePassed && (
                              <div className="flex items-center gap-3 text-rose-600 bg-rose-50 p-4 rounded-2xl text-[10px] leading-relaxed border border-rose-200 font-bold uppercase">
                                <AlertCircle className="w-5 h-5 shrink-0" />
                                Registration for this session closed at {formatTimeSafely(event.deadline)}.
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default MemberView;

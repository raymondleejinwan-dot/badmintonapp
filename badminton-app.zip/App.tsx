
import React, { useState, useEffect } from 'react';
import { ViewState, BadmintonEvent, Participant } from './types';
import { storage } from './services/storage';
import MemberView from './views/MemberView';
import AdminDashboard from './views/AdminDashboard';
import AdminLogin from './views/AdminLogin';
import { Trophy, ShieldCheck, LogOut, Calendar } from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>('MEMBER_VIEW');
  const [events, setEvents] = useState<BadmintonEvent[]>([]);
  const [targetSessionId, setTargetSessionId] = useState<string | null>(null);

  // Initialize data and handle routing
  useEffect(() => {
    const loadedEvents = storage.getEvents();
    if (loadedEvents.length === 0) {
      const demoEvent: BadmintonEvent = {
        id: '1',
        title: 'Weekly Club Match',
        venue: 'Sports Hub - Court 1',
        date: new Date().toISOString().split('T')[0],
        time: '18:00 - 20:00',
        maxSlots: 8,
        deadline: new Date(Date.now() + 86400000).toISOString(),
        participants: [],
        waitingList: [],
        description: 'Casual games for all levels.'
      };
      storage.saveEvents([demoEvent]);
      setEvents([demoEvent]);
    } else {
      setEvents(loadedEvents);
    }

    // Handle initial route from Hash
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash.startsWith('#/session/')) {
        const id = hash.split('/')[2];
        setTargetSessionId(id);
        setView('MEMBER_VIEW');
      } else if (hash === '#/admin') {
        setView('ADMIN_LOGIN');
      } else {
        setView('MEMBER_VIEW');
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Initial check

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigate = (newView: ViewState) => {
    if (newView === 'MEMBER_VIEW') window.location.hash = '';
    else if (newView === 'ADMIN_LOGIN') window.location.hash = '/admin';
    setView(newView);
  };

  const handleRefreshEvents = () => {
    setEvents(storage.getEvents());
  };

  const handleJoin = (eventId: string, name: string, forceWaiting: boolean = false) => {
    const updatedEvents = events.map(e => {
      if (e.id === eventId) {
        const isFull = e.participants.length >= e.maxSlots;
        const newMember: Participant = { 
          id: Math.random().toString(36).substr(2, 9), 
          name, 
          timestamp: Date.now() 
        };

        if (forceWaiting || isFull) {
          return { ...e, waitingList: [...e.waitingList, newMember] };
        } else {
          return { ...e, participants: [...e.participants, newMember] };
        }
      }
      return e;
    });
    setEvents(updatedEvents);
    storage.saveEvents(updatedEvents);
  };

  const handleLeave = (eventId: string, participantId: string) => {
    const updatedEvents = events.map(e => {
      if (e.id === eventId) {
        // If the user is in the waiting list, just remove them
        const inWaitingList = e.waitingList.find(p => p.id === participantId);
        if (inWaitingList) {
          return { 
            ...e, 
            waitingList: e.waitingList.filter(p => p.id !== participantId) 
          };
        }

        // If the user is in confirmed participants, just remove them.
        // We DO NOT automatically promote from waiting list anymore as per request.
        return { 
          ...e, 
          participants: e.participants.filter(p => p.id !== participantId) 
        };
      }
      return e;
    });
    setEvents(updatedEvents);
    storage.saveEvents(updatedEvents);
  };

  return (
    <div className="min-h-screen flex flex-col transition-colors duration-500">
      <nav className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate('MEMBER_VIEW')}>
              <div className="bg-indigo-600 p-1.5 rounded-lg shadow-lg shadow-indigo-200">
                <Trophy className="text-white w-5 h-5" />
              </div>
              <span className="font-black text-xl tracking-tighter text-slate-800">SMASHDASH</span>
            </div>
            
            <div className="hidden md:flex items-center gap-6">
              <button 
                onClick={() => navigate('MEMBER_VIEW')} 
                className={`text-sm font-bold flex items-center gap-2 transition-colors ${view === 'MEMBER_VIEW' ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-900'}`}
              >
                <Calendar className="w-4 h-4" /> Sessions
              </button>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {view === 'ADMIN_DASHBOARD' ? (
              <div className="flex items-center gap-3">
                <span className="hidden sm:inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold uppercase">
                  <ShieldCheck className="w-3.5 h-3.5" /> Admin
                </span>
                <button 
                  onClick={() => navigate('MEMBER_VIEW')}
                  className="p-2 bg-slate-100 rounded-full text-slate-500 hover:text-rose-500 transition-all"
                  title="Logout"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <button 
                onClick={() => navigate('ADMIN_LOGIN')}
                className="flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-indigo-600 transition-colors uppercase tracking-widest"
              >
                <ShieldCheck className="w-4 h-4" />
                {view === 'ADMIN_LOGIN' ? '' : 'Admin Portal'}
              </button>
            )}
          </div>
        </div>
      </nav>

      <main className="flex-1 max-w-5xl mx-auto w-full px-4 sm:px-6 py-8">
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          {view === 'MEMBER_VIEW' && (
            <MemberView 
              events={events} 
              onJoin={handleJoin} 
              onLeave={handleLeave} 
              highlightSessionId={targetSessionId || undefined}
            />
          )}
          {view === 'ADMIN_LOGIN' && (
            <AdminLogin onSuccess={() => setView('ADMIN_DASHBOARD')} />
          )}
          {view === 'ADMIN_DASHBOARD' && (
            <AdminDashboard 
              events={events} 
              onUpdate={handleRefreshEvents} 
            />
          )}
        </div>
      </main>

      <footer className="bg-white border-t border-slate-200 py-12">
        <div className="max-w-5xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex flex-col items-center md:items-start">
            <div className="flex items-center gap-2 mb-4">
              <Trophy className="text-indigo-600 w-6 h-6" />
              <span className="font-black text-lg tracking-tighter">SMASHDASH</span>
            </div>
            <p className="text-slate-400 text-sm">Empowering local badminton communities through technology.</p>
          </div>
          <div className="flex gap-8 text-slate-400 text-sm font-medium">
            <a href="#" className="hover:text-indigo-600 transition-colors" onClick={(e) => { e.preventDefault(); navigate('MEMBER_VIEW'); }}>Sessions</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">About Us</a>
            <a href="#" className="hover:text-indigo-600 transition-colors" onClick={(e) => { e.preventDefault(); navigate('ADMIN_LOGIN'); }}>Admin</a>
          </div>
          <p className="text-slate-300 text-xs">© {new Date().getFullYear()} SmashDash. Built for champions.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;


export interface Participant {
  id: string;
  name: string;
  timestamp: number;
}

export interface BadmintonEvent {
  id: string;
  title: string;
  venue: string;
  date: string;
  time: string;
  maxSlots: number;
  deadline: string; // ISO string
  participants: Participant[];
  waitingList: Participant[];
  description?: string;
}

export type ViewState = 'MEMBER_VIEW' | 'ADMIN_LOGIN' | 'ADMIN_DASHBOARD';
